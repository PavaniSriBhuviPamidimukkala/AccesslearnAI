/**
 * Core Accessibility Engine
 * Handles dynamic UI changes based on the active mode (normal, deaf, blind)
 * 
 * Capabilities:
 * - Deaf Mode: Enhances text sizes trivially, visually alerts on toasts instead of audio
 * - Blind Mode: Applies high contrast colors globally, manages focus, invokes Text-to-Speech
 */

window.AccessibilityEngine = class AccessibilityEngine {
    constructor() {
        this.synth = window.speechSynthesis;
        this.isSpeaking = false;
        this.lastSpokenFragment = null;

        // Listen to state changes to apply modes
        store.subscribe((state) => {
            this.applyMode(state.accessibility.mode);
        });

        // Setup global click listener for Blind mode "tap to read"
        document.addEventListener('click', (e) => this.handleBlindModeClick(e));

        // Announce route changes when in Blind Mode
        window.addEventListener('hashchange', () => {
            setTimeout(() => this.announcePageLoad(), 500); // Give DOM time to update
        });

        // Initialize with default/persisted state
        this.applyMode(store.getState().accessibility.mode);
    }

    applyMode(mode) {
        const body = document.body;

        // Remove existing mode classes
        body.classList.remove('deaf-mode', 'blind-mode');

        // Stop any currently speaking audio
        this.stopSpeaking();

        if (mode === 'deaf') {
            body.classList.add('deaf-mode');
            this.showToast("Deaf Mode Activated: Enhancing visual cues and text sizes.");
        } else if (mode === 'blind') {
            body.classList.add('blind-mode');
            this.speak("Blind Mode activated. Tap anywhere on the page to read text aloud.");
        } else {
            // normal
            this.showToast("Normal Mode activated.");
        }
    }

    /**
     * Shows a visual toast message.
     * In Deaf mode, these alerts flash distinctively.
     */
    showToast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const state = store.getState();
        const mode = state.accessibility.mode;

        const toast = document.createElement('div');
        const isDeaf = mode === 'deaf';

        // Tailwind classes for the toast
        toast.className = `p-4 rounded shadow-lg flex items-center justify-between text-white transform transition-all duration-300 translate-y-0 opacity-100 ${type === 'error' ? 'bg-red-600' :
            type === 'success' ? 'bg-green-600' : 'bg-blue-600'
            } ${isDeaf ? 'visual-alert scale-105 border-4' : ''}`;

        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <span>${message}</span>
            <button class="ml-4 text-white hover:text-gray-200 focus:outline-none" aria-label="Close alert">
                &times;
            </button>
        `;

        toast.querySelector('button').addEventListener('click', () => {
            toast.remove();
        });

        container.appendChild(toast);

        // Announce toast in blind mode
        if (mode === 'blind') {
            this.speak(message);
        }

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (document.body.contains(toast)) {
                toast.style.opacity = '0';
                setTimeout(() => toast.remove(), 300);
            }
        }, 5000);
    }

    // --- Web Speech API Methods for Blind Mode ---

    speak(text) {
        const state = store.getState();
        if (state.accessibility.mode !== 'blind') return;

        if (!this.synth) {
            console.warn("Speech Synthesis API not available in this browser.");
            return;
        }

        // Prevent repeating the same tap immediately
        if (this.lastSpokenFragment === text && this.synth.speaking) {
            return;
        }

        this.stopSpeaking();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1.0;
        utterance.pitch = 1.0;

        utterance.onstart = () => { this.isSpeaking = true; this.lastSpokenFragment = text; };
        utterance.onend = () => { this.isSpeaking = false; this.lastSpokenFragment = null; };
        utterance.onerror = (e) => console.error("Speech Synthesis Error:", e);

        this.synth.speak(utterance);
    }

    stopSpeaking() {
        if (this.synth && this.synth.speaking) {
            this.synth.cancel();
            this.isSpeaking = false;
        }
    }

    handleBlindModeClick(event) {
        const state = store.getState();
        if (state.accessibility.mode !== 'blind') return;

        const target = event.target;

        // Find closest element with text or ARIA label
        let textToRead = target.getAttribute('aria-label') || target.innerText;

        // If it's an image, look for alt tag
        if (target.tagName === 'IMG') {
            textToRead = target.getAttribute('alt') || "Image with no description";
        } else if (!textToRead && target.closest('button, a')) {
            const parent = target.closest('button, a');
            textToRead = parent.getAttribute('aria-label') || parent.innerText;
        }

        if (textToRead && textToRead.trim().length > 0) {
            this.speak(textToRead.trim());
        }
    }

    announcePageLoad() {
        const state = store.getState();
        if (state.accessibility.mode !== 'blind') return;

        const h1 = document.querySelector('h1');
        const pageTitle = h1 ? h1.innerText : "New Page Loaded";

        this.speak(`Navigated to: ${pageTitle}.`);
    }
}
