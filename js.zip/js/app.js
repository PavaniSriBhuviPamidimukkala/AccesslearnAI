// Route Components are mapped to window objects

const HomeView = {
    path: '/',
    component: async () => {
        return `
            <div class="flex flex-col items-center justify-center py-20 text-center animate-fade-in">
                <div class="mb-8">
                    <span class="inline-block p-3 rounded-full bg-primary/10 text-primary mb-4">
                        <i data-lucide="brain-circuit" class="w-10 h-10"></i>
                    </span>
                    <h1 class="text-4xl md:text-6xl font-extrabold text-gray-900 dark:text-white mb-6 tracking-tight">
                        Empowering Learning <br/><span class="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Without Barriers</span>
                    </h1>
                    <p class="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto leading-relaxed">
                        AccessLearn AI provides real-time accessibility modes, adapting instantly to your needs with AI-driven transcripts, text-to-speech, and visual cues.
                    </p>
                </div>
                
                <div class="flex gap-4">
                    <a href="#/courses" class="px-8 py-3 rounded-lg bg-primary text-white font-semibold shadow-lg shadow-primary/30 hover:bg-primary/90 transition-all flex items-center gap-2">
                        Get Started <i data-lucide="arrow-right" class="w-5 h-5"></i>
                    </a>
                    <a href="#/login" class="px-8 py-3 rounded-lg bg-white text-gray-900 border border-gray-200 font-semibold shadow-sm hover:bg-gray-50 transition-all">
                        Login
                    </a>
                </div>

                <div class="mt-20 w-full grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
                    <div class="p-6 bg-white dark:bg-darkSurface rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 card-hover">
                        <div class="w-12 h-12 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center mb-4">
                            <i data-lucide="sun"></i>
                        </div>
                        <h3 class="text-xl font-bold mb-2">Standard Mode</h3>
                        <p class="text-gray-600 dark:text-gray-400">Our default beautifully crafted interface, optimized for standard learning workflows.</p>
                    </div>
                    <div class="p-6 bg-white dark:bg-darkSurface rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 card-hover">
                        <div class="w-12 h-12 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center mb-4">
                            <i data-lucide="ear-off"></i>
                        </div>
                        <h3 class="text-xl font-bold mb-2">Deaf Mode</h3>
                        <p class="text-gray-600 dark:text-gray-400">Audio muting, prominent subtitles, visual alert substitutions, and increased text readability.</p>
                    </div>
                    <div class="p-6 bg-white dark:bg-darkSurface rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 card-hover">
                        <div class="w-12 h-12 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center mb-4">
                            <i data-lucide="eye-off"></i>
                        </div>
                        <h3 class="text-xl font-bold mb-2">Blind Mode</h3>
                        <p class="text-gray-600 dark:text-gray-400">High contrast layouts, full AI-powered text-to-speech, and optimized keyboard navigation arrays.</p>
                    </div>
                </div>
            </div>
        `;
    },
    afterRender: async () => {
        // Nothing special needed right now
    }
};

const NotFoundView = {
    path: '/404',
    component: async () => `
        <div class="text-center py-20">
            <h1 class="text-6xl font-bold text-gray-900 mb-4">404</h1>
            <p class="text-xl text-gray-600 mb-8">Page not found</p>
            <a href="#/" class="text-primary hover:underline font-medium">Return Home</a>
        </div>
    `
};

// Main Navbar Component Injector
function initializeNavbar() {
    const navContainer = document.getElementById('nav-container');
    if (!navContainer) return;

    navContainer.innerHTML = `
        <nav class="sticky top-0 z-40 w-full glass">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between h-16 items-center">
                    <div class="flex items-center">
                        <a href="#/" class="flex items-center gap-2 group" aria-label="AccessLearn AI Home">
                            <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-md">
                                <i data-lucide="graduation-cap" class="text-white w-5 h-5"></i>
                            </div>
                            <span class="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300">AccessLearn AI</span>
                        </a>
                    </div>
                    
                    <div class="flex items-center space-x-4">
                        <!-- Desktop Navigation links -->
                        <div id="nav-auth-container" class="hidden md:flex items-center space-x-2 mr-4 border-r border-gray-200 dark:border-gray-700 pr-4">
                            <!-- Auth Links injected here -->
                        </div>

                        <!-- Mode Selector -->
                        <div class="relative flex items-center bg-gray-100 dark:bg-gray-800 p-1 rounded-lg border border-gray-200 dark:border-gray-700" role="group" aria-label="Accessibility Modes">
                            <button id="mode-normal" class="mode-btn px-3 py-1.5 rounded-md text-sm font-medium transition-all" data-mode="normal" aria-pressed="false" title="Normal Mode">
                                <i data-lucide="sun" class="w-4 h-4 inline-block mr-1"></i> Normal
                            </button>
                            <button id="mode-deaf" class="mode-btn px-3 py-1.5 rounded-md text-sm font-medium transition-all" data-mode="deaf" aria-pressed="false" title="Deaf Mode">
                                <i data-lucide="ear-off" class="w-4 h-4 inline-block mr-1"></i> Deaf
                            </button>
                            <button id="mode-blind" class="mode-btn px-3 py-1.5 rounded-md text-sm font-medium transition-all" data-mode="blind" aria-pressed="false" title="Blind Mode">
                                <i data-lucide="eye-off" class="w-4 h-4 inline-block mr-1"></i> Blind
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    `;

    // Mode Selector Logic
    const modeBtns = document.querySelectorAll('.mode-btn');

    const updateNavStyles = (activeMode) => {
        modeBtns.forEach(btn => {
            const btnMode = btn.dataset.mode;
            if (activeMode === btnMode) {
                btn.classList.add('bg-white', 'text-gray-900', 'shadow-sm', 'dark:bg-gray-700', 'dark:text-white');
                btn.classList.remove('text-gray-500', 'hover:text-gray-700');
                btn.setAttribute('aria-pressed', 'true');
            } else {
                btn.classList.remove('bg-white', 'text-gray-900', 'shadow-sm', 'dark:bg-gray-700', 'dark:text-white');
                btn.classList.add('text-gray-500', 'hover:text-gray-700');
                btn.setAttribute('aria-pressed', 'false');
            }
        });
    };

    // Attach listeners
    modeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            store.dispatch(setAccessibilityMode(btn.dataset.mode));
        });
    });

    // Subscribe to store updates for styling side-effects
    store.subscribe((state) => {
        updateNavStyles(state.accessibility.mode);
    });

    // Initial state set
    updateNavStyles(store.getState().accessibility.mode);
    updateNavAuthUI(store.getState().auth.isAuthenticated);

    // Listen for Auth changes
    let currentAuth = store.getState().auth.isAuthenticated;
    store.subscribe((state) => {
        if (state.auth.isAuthenticated !== currentAuth) {
            currentAuth = state.auth.isAuthenticated;
            updateNavAuthUI(currentAuth);
        }
    });
}


// Application Bootstrap Function
function initApp() {
    console.log("Bootstraping AccessLearn AI Vanilla App...");

    // 1. Initialize Global Accessibility Engine
    window.accessibilityEngine = new AccessibilityEngine();

    // 2. Setup Navbar (static shell)
    initializeNavbar();

    // 3. Initialize Router mapping views
    const routes = [
        HomeView,
        LoginView,
        RegisterView,
        DashboardView,
        CoursesView,
        QuizView,
        VideoLearningView,
        NotFoundView
    ];

    // We bind it to window so we can control navigation from console or elsewhere if needed
    window.appRouter = new Router(routes, 'app-root');

    // Render icons on first load
    if (window.lucide) {
        window.lucide.createIcons();
    }
}

// Run init when DOM is fully loaded
document.addEventListener('DOMContentLoaded', initApp);
