const mockQuestions = [
    {
        id: 'q1',
        text: 'Which ARIA attribute is used to indicate that an element is dynamically updated?',
        options: ['aria-hidden', 'aria-live', 'aria-dynamic', 'aria-updated'],
        correctIndex: 1,
        explanation: 'aria-live regions inform screen readers that content is updated dynamically so it can be announced properly.'
    },
    {
        id: 'q2',
        text: 'What is the recommended minimum contrast ratio for normal text according to WCAG AA?',
        options: ['3.0:1', '4.5:1', '7.0:1', '2.5:1'],
        correctIndex: 1,
        explanation: 'WCAG 2.1 AA requires a contrast ratio of at least 4.5:1 for normal text and 3:1 for large text.'
    }
];

window.QuizView = {
    path: '/course/:id/quiz',
    component: async (params) => {
        // Ensure state carries over (usually we'd fetch specific quiz data here)
        return `
            <div class="max-w-3xl mx-auto space-y-8 animate-fade-in" id="quiz-container">
                <div class="mb-8">
                    <a href="#/courses" class="inline-flex items-center text-sm font-medium text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 mb-6 transition-colors">
                        <i data-lucide="arrow-left" class="w-4 h-4 mr-1"></i> Back to Courses
                    </a>
                    <div class="flex justify-between items-end">
                        <div>
                            <h1 class="text-3xl font-bold text-gray-900 dark:text-white">Knowledge Check</h1>
                            <p class="text-gray-600 dark:text-gray-400 mt-2" id="quiz-progress-text">Question 1 of ${mockQuestions.length}</p>
                        </div>
                        <div class="text-right">
                             <span class="inline-block px-3 py-1 bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 rounded-full text-xs font-bold uppercase tracking-wider">
                                Module 4
                            </span>
                        </div>
                    </div>
                </div>

                <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-8 hidden md:block">
                    <div id="progress-bar" class="bg-primary h-2 rounded-full transition-all duration-500" style="width: 50%"></div>
                </div>

                <div id="question-card" class="bg-white dark:bg-darkSurface p-8 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
                    <!-- Question Content populated via JS -->
                </div>
                
                <div class="flex justify-between items-center pt-4">
                    <button id="prev-btn" class="px-6 py-3 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed">
                        Previous
                    </button>
                    <button id="next-btn" class="px-8 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors shadow-md focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 flex items-center gap-2">
                        Next <i data-lucide="arrow-right" class="w-4 h-4"></i>
                    </button>
                </div>
            </div>
        `;
    },
    afterRender: async (params) => {
        let currentIdx = 0;
        let selectedAnswers = new Array(mockQuestions.length).fill(null);
        let showResults = false;

        const container = document.getElementById('question-card');
        const prevBtn = document.getElementById('prev-btn');
        const nextBtn = document.getElementById('next-btn');
        const progressText = document.getElementById('quiz-progress-text');
        const progressBar = document.getElementById('progress-bar');

        function renderCard() {
            if (showResults) {
                renderResults();
                return;
            }

            const q = mockQuestions[currentIdx];

            // Build options HTML setup for keyboard navigation & ARIA
            const optionsHtml = q.options.map((opt, i) => {
                const isSelected = selectedAnswers[currentIdx] === i;
                return `
                    <label class="relative flex items-start p-4 cursor-pointer rounded-xl border-2 transition-all 
                        ${isSelected ? 'border-primary bg-indigo-50 dark:bg-indigo-900/10' : 'border-gray-200 dark:border-gray-700 hover:border-primary/50 hover:bg-gray-50 dark:hover:bg-gray-800'}">
                        <div class="flex items-center h-5">
                            <input type="radio" name="question-${currentIdx}" value="${i}" ${isSelected ? 'checked' : ''}
                                class="w-5 h-5 text-primary border-gray-300 focus:ring-primary focus:ring-offset-2 dark:border-gray-600 dark:bg-gray-700">
                        </div>
                        <div class="ml-3 flex flex-col">
                            <span class="text-base font-medium ${isSelected ? 'text-primary dark:text-indigo-400' : 'text-gray-900 dark:text-white'}">${opt}</span>
                        </div>
                    </label>
                `;
            }).join('');

            container.innerHTML = `
                <fieldset>
                    <legend class="text-2xl font-bold text-gray-900 dark:text-white mb-6 leading-relaxed">${q.text}</legend>
                    <div class="space-y-4" role="radiogroup" aria-labelledby="question-text">
                        ${optionsHtml}
                    </div>
                </fieldset>
            `;

            // Update UI State
            prevBtn.disabled = currentIdx === 0;
            nextBtn.innerHTML = currentIdx === mockQuestions.length - 1 ? 'Submit Quiz <i data-lucide="check" class="w-4 h-4"></i>' : 'Next <i data-lucide="arrow-right" class="w-4 h-4"></i>';
            progressText.innerText = `Question ${currentIdx + 1} of ${mockQuestions.length}`;
            progressBar.style.width = `${((currentIdx + 1) / mockQuestions.length) * 100}%`;

            // Re-bind lucide icons since we replaced HTML
            if (window.lucide) window.lucide.createIcons();

            // Bind radio change evts
            container.querySelectorAll('input[type="radio"]').forEach(radio => {
                radio.addEventListener('change', (e) => {
                    selectedAnswers[currentIdx] = parseInt(e.target.value);
                    renderCard(); // re-render to get selection styles

                    // In Blind mode, annouce selection
                    if (window.accessibilityEngine && store.getState().accessibility.mode === 'blind') {
                        window.accessibilityEngine.speak(`Selected option: ${q.options[selectedAnswers[currentIdx]]}`);
                    }
                });
            });

            // Speak Question in Blind mode when it loads
            if (window.accessibilityEngine && store.getState().accessibility.mode === 'blind') {
                window.accessibilityEngine.speak(`Question ${currentIdx + 1}: ${q.text}`);
            }
        }

        function renderResults() {
            let score = 0;
            const resultsHtml = mockQuestions.map((q, i) => {
                const isCorrect = selectedAnswers[i] === q.correctIndex;
                if (isCorrect) score++;

                return `
                    <div class="p-6 rounded-xl border-2 mb-4 ${isCorrect ? 'border-green-200 bg-green-50 dark:border-green-900/50 dark:bg-green-900/10' : 'border-red-200 bg-red-50 dark:border-red-900/50 dark:bg-red-900/10'}">
                        <div class="flex gap-3 mb-2">
                            ${isCorrect
                        ? '<i data-lucide="check-circle" class="w-6 h-6 text-green-600 dark:text-green-400 mt-1"></i>'
                        : '<i data-lucide="x-circle" class="w-6 h-6 text-red-600 dark:text-red-400 mt-1"></i>'}
                        <div>
                            <h3 class="font-bold text-lg text-gray-900 dark:text-white">${q.text}</h3>
                            <p class="mt-2 text-gray-700 dark:text-gray-300">
                                Your answer: <span class="font-semibold">${selectedAnswers[i] !== null ? q.options[selectedAnswers[i]] : 'None'}</span>
                            </p>
                            ${!isCorrect ? `
                                    <p class="mt-1 text-green-700 dark:text-green-400 font-medium">
                                        Correct answer: ${q.options[q.correctIndex]}
                                    </p>
                                ` : ''}
                            <div class="mt-4 p-4 bg-white/60 dark:bg-black/20 rounded-lg text-sm text-gray-800 dark:text-gray-200 border border-gray-200 dark:border-gray-700">
                                <strong class="font-semibold block mb-1">Explanation:</strong> ${q.explanation}
                            </div>
                        </div>
                    </div>
                </div>
                `;
            }).join('');

            // Save Progress to Firestore if logged in
            const state = store.getState();
            const totalQuestions = (window.liveQuestions || mockQuestions).length;
            const percentage = Math.round((score / totalQuestions) * 100);

            if (state.auth.isAuthenticated && state.auth.user && state.auth.user.id) {
                db.collection('users').doc(state.auth.user.id).collection('progress').add({
                    courseId: params.id,
                    score: score,
                    total: totalQuestions,
                    percentage: percentage,
                    completedAt: firebase.firestore.FieldValue.serverTimestamp()
                }).catch(err => console.error("Error saving progress:", err));
            }

            container.innerHTML = `
                <div class="text-center mb-8">
                    <div class="w-24 h-24 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                        <span class="text-4xl font-bold text-primary">${percentage}%</span>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900 dark:text-white mb-2">Quiz Completed!</h2>
                    <p class="text-gray-600 dark:text-gray-400">You got ${score} out of ${totalQuestions} correct.</p>
                </div>
                <div>
                    ${resultsHtml}
                </div>
            `;

            prevBtn.style.display = 'none';
            nextBtn.innerHTML = 'Return to Dashboard';
            nextBtn.onclick = () => window.appRouter.navigate('/dashboard');

            if (window.lucide) window.lucide.createIcons();

            if (window.accessibilityEngine && store.getState().accessibility.mode === 'blind') {
                window.accessibilityEngine.speak(`Quiz completed. You scored ${score} out of ${mockQuestions.length}.`);
            }
        }

        // Navigation bound
        prevBtn.addEventListener('click', () => {
            if (currentIdx > 0 && !showResults) {
                currentIdx--;
                renderCard();
            }
        });

        nextBtn.addEventListener('click', () => {
            if (showResults) return; // handled locally

            const hasAnswered = selectedAnswers[currentIdx] !== null;
            if (!hasAnswered) {
                window.accessibilityEngine?.showToast("Please select an answer to continue.", "error");
                return;
            }

            if (currentIdx < mockQuestions.length - 1) {
                currentIdx++;
                renderCard();
            } else {
                // Submit!
                showResults = true;
                window.accessibilityEngine?.showToast("Quiz submitted successfully!", "success");
                renderCard();
            }
        });

        // Fetch real quiz from Firestore if available
        const courseId = params.id;
        try {
            const snapshot = await db.collection('courses').doc(courseId).collection('quizzes').get();
            if (!snapshot.empty) {
                window.liveQuestions = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                // If it's the first time landing here, re-render with new questions
                if (!window.liveQuestionsInitialized) {
                    window.liveQuestionsInitialized = true;
                    renderCard();
                }
            }
        } catch (error) {
            console.error("Error fetching quiz questions:", error);
        }

        // initial render
        renderCard();
    }
};
