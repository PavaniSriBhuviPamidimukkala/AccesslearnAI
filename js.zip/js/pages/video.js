window.VideoLearningView = {
    path: '/course/:id/video',
    component: async (params) => {
        const state = store.getState();
        const isDeafMode = state.accessibility.mode === 'deaf';

        // Find the course from live data, or fetch from Firestore if missing
        const courseId = params.id;
        let course = (window.liveCourses || []).find(c => c.id === courseId);

        if (!course && typeof db !== 'undefined') {
            try {
                // Fetch the specific course if navigating directly to video page
                const doc = await db.collection('courses').doc(courseId).get();
                if (doc.exists) {
                    course = { id: doc.id, ...doc.data() };

                    if (!window.liveCourses) window.liveCourses = [];
                    window.liveCourses.push(course);
                }
            } catch (error) {
                console.error("Error fetching course for video:", error);
            }
        }

        course = course || {
            title: 'Course Not Found',
            'video url': null
        };

        const vUrl = course['video url'] || course.videoUrl; // fallback just in case
        const isYouTube = vUrl && (vUrl.includes('youtube.com') || vUrl.includes('youtu.be'));

        // Convert standard YouTube links to embed format
        let embedUrl = vUrl;
        if (isYouTube) {
            try {
                if (vUrl.includes('youtu.be/')) {
                    const videoId = vUrl.split('youtu.be/')[1].split('?')[0];
                    embedUrl = `https://www.youtube.com/embed/${videoId}`;
                } else {
                    const urlObj = new URL(vUrl);
                    const videoId = urlObj.searchParams.get('v');
                    if (videoId) {
                        embedUrl = `https://www.youtube.com/embed/${videoId}`;
                    }
                }
            } catch (e) {
                console.warn("Failed to parse YouTube URL:", e);
            }
        }

        return `
            <div class="max-w-7xl mx-auto space-y-6 animate-fade-in pb-12">
                <!-- Header -->
                <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-2">
                    <div>
                        <a href="#/courses" class="inline-flex items-center text-sm font-medium text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 mb-2 transition-colors">
                            <i data-lucide="arrow-left" class="w-4 h-4 mr-1"></i> Back to Courses
                        </a>
                        <h1 class="text-3xl font-bold text-gray-900 dark:text-white" id="video-title">${course.title}</h1>
                    </div>
                    <div class="flex gap-3">
                        <button id="btn-ai-assistant" class="px-4 py-2 bg-indigo-100 text-indigo-700 dark:bg-indigo-900/50 dark:text-indigo-300 rounded-lg hover:bg-indigo-200 dark:hover:bg-indigo-900 transition-colors font-medium flex items-center gap-2">
                            <i data-lucide="bot"></i> AI Assistant
                        </button>
                        <a href="#/course/${params.id}/quiz" class="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors shadow-sm font-medium flex items-center gap-2">
                            Take Quiz <i data-lucide="arrow-right" class="w-4 h-4"></i>
                        </a>
                    </div>
                </div>

                <!-- Main Grid -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 relative">
                    
                    <!-- Video Section (Spans 2 cols) -->
                    <div class="lg:col-span-2 space-y-4">
                        <div class="relative bg-black rounded-2xl overflow-hidden aspect-video shadow-lg group">
                            
                            ${vUrl ? `
                                ${isYouTube ? `
                                    <iframe class="w-full h-full" 
                                            src="${embedUrl}" 
                                            title="YouTube video player" 
                                            frameborder="0" 
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                                            referrerpolicy="strict-origin-when-cross-origin"
                                            allowfullscreen>
                                    </iframe>
                                ` : `
                                    <!-- Real HTML5 Video Player -->
                                    <video id="course-video" class="w-full h-full object-contain" controls crossorigin="anonymous">
                                        <source src="${vUrl}" type="video/mp4">
                                        Your browser does not support the video tag.
                                    </video>
                                `}
                            ` : `
                                <!-- Placeholder Video Player (if no URL provided in Firestore) -->
                                <div class="absolute inset-0 flex items-center justify-center bg-gray-900 text-white flex-col text-center p-6">
                                    <i data-lucide="video-off" class="w-16 h-16 text-gray-500 mb-4"></i>
                                    <h3 class="text-xl font-bold mb-2">No Video Available</h3>
                                    <p class="text-gray-400 text-sm">Please add a 'video url' field to this course in your Firestore Database.</p>
                                </div>
                            `}
                            
                            <!-- Mock Subtitles Overlay (forced on in Deaf Mode) - Usually replaced by VTT tracks in production -->
                            <div id="video-subtitles" class="absolute bottom-20 left-0 right-0 text-center pointer-events-none transition-opacity duration-300 ${isDeafMode ? 'opacity-100' : 'opacity-0'}">
                                <span class="bg-black/80 text-white px-4 py-2 rounded text-lg lg:text-xl font-medium inline-block max-w-2xl mx-auto shadow-md border border-white/10">
                                    [Subtitles Overlay Enabled]
                                </span>
                            </div>
                        </div>

                        <!-- Video Meta & AI Notes Generator -->
                        <div class="bg-white dark:bg-darkSurface p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
                            <div class="flex justify-between items-center mb-4 border-b border-gray-100 dark:border-gray-800 pb-4">
                                <div>
                                    <h2 class="text-xl font-bold text-gray-900 dark:text-white">AI Generated Notes</h2>
                                    <p class="text-sm text-gray-500">Automatically extracted key takeaways</p>
                                </div>
                                <button class="p-2 text-gray-500 hover:text-primary hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg transition-colors" title="Download Notes">
                                    <i data-lucide="download"></i>
                                </button>
                            </div>
                            <div class="prose prose-sm md:prose-base prose-indigo dark:prose-invert max-w-none">
                                <ul>
                                    <li><strong>ARIA regions:</strong> Used to inject dynamic content selectively.</li>
                                    <li><strong>aria-live="polite":</strong> Screen readers will wait until the user is idle before speaking.</li>
                                    <li><strong>aria-live="assertive":</strong> Interrupts the user immediately (good for errors/alerts).</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Right Sidebar: Interactive Transcript & Assisant Panel -->
                    <div class="lg:col-span-1 flex flex-col h-[600px] lg:h-auto gap-4">
                        
                        <!-- Transcript Panel -->
                        <div class="bg-white dark:bg-darkSurface rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 flex flex-col h-full overflow-hidden">
                            <div class="p-4 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center bg-gray-50 dark:bg-gray-800/50">
                                <h3 class="font-bold flex items-center gap-2"><i data-lucide="file-text" class="w-5 h-5 text-gray-500"></i> Transcript</h3>
                                <div class="relative">
                                    <i data-lucide="search" class="w-4 h-4 absolute left-2 top-1.5 text-gray-400"></i>
                                    <input type="text" placeholder="Search..." class="pl-8 pr-2 py-1 text-sm bg-white dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded">
                                </div>
                            </div>
                            <div class="flex-1 overflow-y-auto p-4 space-y-4 text-sm" id="transcript-container">
                                <div class="flex gap-4 p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded cursor-pointer transition-colors group">
                                    <span class="text-primary font-mono shrink-0">12:05</span>
                                    <p class="text-gray-700 dark:text-gray-300 group-hover:text-gray-900 dark:group-hover:text-white">When building dynamic interfaces, relying purely on visual cues is a mistake.</p>
                                </div>
                                <div class="flex gap-4 p-2 bg-indigo-50 dark:bg-indigo-900/20 border-l-2 border-primary rounded cursor-pointer transition-colors group">
                                    <span class="text-primary font-mono shrink-0">12:30</span>
                                    <p class="font-medium text-gray-900 dark:text-white">...and this is why ARIA labels are absolutely crucial for screen readers to announce interactive state changes.</p>
                                </div>
                                <div class="flex gap-4 p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded cursor-pointer transition-colors group">
                                    <span class="text-primary font-mono shrink-0">12:45</span>
                                    <p class="text-gray-700 dark:text-gray-300 group-hover:text-gray-900 dark:group-hover:text-white">Let's look at an example using a role="alert" toast notification.</p>
                                </div>
                                <!-- More mocked transcripts would go here -->
                                <div class="flex gap-4 p-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded cursor-pointer transition-colors group">
                                    <span class="text-primary font-mono shrink-0">13:10</span>
                                    <p class="text-gray-700 dark:text-gray-300 group-hover:text-gray-900 dark:group-hover:text-white">By applying the aria-live attribute, we instruct the browser's accessibility API to observe DOM mutations.</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- AI Assistant Chat Panel (Hidden by default) -->
                <div id="ai-chat-panel" class="fixed right-0 top-0 bottom-0 w-full sm:w-96 bg-white dark:bg-darkSurface shadow-2xl z-50 transform translate-x-full transition-transform duration-300 flex flex-col border-l border-gray-200 dark:border-gray-800">
                    <div class="p-4 border-b border-gray-200 dark:border-gray-800 flex justify-between items-center bg-indigo-600 text-white">
                        <div class="flex items-center gap-3">
                            <i data-lucide="bot" class="w-6 h-6"></i>
                            <div>
                                <h3 class="font-bold">AccessLearn Assistant</h3>
                                <p class="text-xs opacity-80 pl-1">AI Doubt Solver</p>
                            </div>
                        </div>
                        <button id="btn-close-chat" class="p-2 hover:bg-white/20 rounded-lg transition-colors" aria-label="Close chat">
                            <i data-lucide="x" class="w-5 h-5"></i>
                        </button>
                    </div>
                    
                    <div class="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50 dark:bg-gray-900/50" id="chat-messages">
                        <div class="flex gap-3">
                            <div class="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex flex-shrink-0 items-center justify-center text-indigo-600 dark:text-indigo-400">
                                <i data-lucide="bot" class="w-4 h-4"></i>
                            </div>
                            <div class="bg-white dark:bg-gray-800 p-3 rounded-2xl rounded-tl-none shadow-sm text-sm text-gray-800 dark:text-gray-200 border border-gray-100 dark:border-gray-700">
                                Hi there! I'm scanning the current transcript for "ARIA Roles in Practice". What doubts do you have about this topic?
                            </div>
                        </div>
                    </div>
                    
                    <div class="p-4 bg-white dark:bg-darkSurface border-t border-gray-200 dark:border-gray-800">
                        <form id="chat-form" class="flex gap-2">
                            <input type="text" id="chat-input" placeholder="Ask a question..." class="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-full focus:outline-none focus:ring-2 focus:ring-primary dark:bg-gray-800 dark:text-white" autocomplete="off">
                            <button type="submit" class="w-10 h-10 rounded-full bg-primary text-white shadow-sm flex items-center justify-center hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2">
                                <i data-lucide="send" class="w-4 h-4 ml-1"></i>
                            </button>
                        </form>
                    </div>
                </div>
                <!-- Chat Backdrop -->
                <div id="chat-backdrop" class="fixed inset-0 bg-black/20 dark:bg-black/50 backdrop-blur-sm z-40 hidden transition-opacity"></div>
            </div>
        `;
    },
    afterRender: async () => {
        // Handle Subtitles Toggle logic
        const ccBtn = document.getElementById('btn-cc');
        const subtitlesOverlay = document.getElementById('video-subtitles');

        let localSubtitlesEnabled = store.getState().accessibility.mode === 'deaf';

        if (ccBtn && subtitlesOverlay) {
            ccBtn.addEventListener('click', () => {
                localSubtitlesEnabled = !localSubtitlesEnabled;
                ccBtn.setAttribute('aria-pressed', localSubtitlesEnabled.toString());

                if (localSubtitlesEnabled) {
                    ccBtn.classList.add('text-green-400', 'bg-white/20', 'px-2', 'py-1', 'rounded');
                    ccBtn.classList.remove('hover:text-primary');
                    subtitlesOverlay.classList.remove('opacity-0');
                    subtitlesOverlay.classList.add('opacity-100');

                    if (window.accessibilityEngine) window.accessibilityEngine.showToast("Subtitles Enabled");
                } else {
                    ccBtn.classList.remove('text-green-400', 'bg-white/20', 'px-2', 'py-1', 'rounded');
                    ccBtn.classList.add('hover:text-primary');
                    subtitlesOverlay.classList.add('opacity-0');
                    subtitlesOverlay.classList.remove('opacity-100');

                    if (window.accessibilityEngine) window.accessibilityEngine.showToast("Subtitles Disabled");
                }
            });
        }

        // Handle AI Chat Panel logic
        const chatPanel = document.getElementById('ai-chat-panel');
        const chatBackdrop = document.getElementById('chat-backdrop');
        const btnOpenChat = document.getElementById('btn-ai-assistant');
        const btnCloseChat = document.getElementById('btn-close-chat');
        const chatForm = document.getElementById('chat-form');
        const chatInput = document.getElementById('chat-input');
        const chatMessages = document.getElementById('chat-messages');

        const toggleChat = (show) => {
            if (show) {
                chatPanel.classList.remove('translate-x-full');
                chatBackdrop.classList.remove('hidden');
                setTimeout(() => chatInput.focus(), 300);
            } else {
                chatPanel.classList.add('translate-x-full');
                chatBackdrop.classList.add('hidden');
            }
        };

        if (btnOpenChat) btnOpenChat.addEventListener('click', () => toggleChat(true));
        if (btnCloseChat) btnCloseChat.addEventListener('click', () => toggleChat(false));
        if (chatBackdrop) chatBackdrop.addEventListener('click', () => toggleChat(false));

        // Mock Chat submission
        if (chatForm) {
            chatForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const msg = chatInput.value.trim();
                if (!msg) return;

                // Add user msg
                chatMessages.innerHTML += `
                    <div class="flex gap-3 flex-row-reverse mt-4">
                        <div class="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex flex-shrink-0 items-center justify-center text-gray-600 dark:text-gray-300">
                            <i data-lucide="user" class="w-4 h-4"></i>
                        </div>
                        <div class="bg-primary p-3 rounded-2xl rounded-tr-none shadow-sm text-sm text-white">
                            ${msg}
                        </div>
                    </div>
                `;

                chatInput.value = '';
                chatMessages.scrollTop = chatMessages.scrollHeight;
                if (window.lucide) window.lucide.createIcons();

                // Mock typing and reply
                setTimeout(() => {
                    chatMessages.innerHTML += `
                        <div class="flex gap-3 mt-4 animate-fade-in">
                            <div class="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex flex-shrink-0 items-center justify-center text-indigo-600 dark:text-indigo-400">
                                <i data-lucide="bot" class="w-4 h-4"></i>
                            </div>
                            <div class="bg-white dark:bg-gray-800 p-3 rounded-2xl rounded-tl-none shadow-sm text-sm text-gray-800 dark:text-gray-200 border border-gray-100 dark:border-gray-700">
                                Great question! Both <code>aria-live="polite"</code> and <code>aria-live="assertive"</code> announce changes, but polite waits until the user finishes their current task, whereas assertive interrupts them immediately. Use assertive sparingly for critical alerts!
                            </div>
                        </div>
                    `;
                    chatMessages.scrollTop = chatMessages.scrollHeight;
                    if (window.lucide) window.lucide.createIcons();

                    // In blind mode, optionally read out the response automatically if focus is in chat
                    if (window.accessibilityEngine && store.getState().accessibility.mode === 'blind') {
                        window.accessibilityEngine.speak("Assistant replied: Great question! Both polite and assertive announce changes...");
                    }
                }, 1200);
            });
        }
    }
};
