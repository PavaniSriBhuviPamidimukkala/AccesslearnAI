const mockCourses = [
    { id: 'react-101', title: 'Advanced React Accessibility', category: 'Frontend', level: 'Intermediate', duration: '4h 30m', description: 'Learn to build fully screen-reader compliant apps utilizing ARIA roles and keyboard management.' },
    { id: 'wcag-basics', title: 'WCAG 2.2 Fundamentals', category: 'Design', level: 'Beginner', duration: '2h 15m', description: 'Understanding the Web Content Accessibility Guidelines and how to apply them to your designs.' },
    { id: 'inclusive-ux', title: 'Inclusive UX Design', category: 'Design', level: 'All Levels', duration: '3h 45m', description: 'Design digital experiences that work beautifully for users of all abilities and backgrounds.' },
    { id: 'testing-a11y', title: 'Automated Accessibility Testing', category: 'QA', level: 'Advanced', duration: '5h', description: 'Integrate tools like axe-core into your CI/CD pipelines to catch accessibility issues early.' }
];

window.CoursesView = {
    path: '/courses',
    component: async () => `
        <div class="space-y-8 animate-fade-in">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900 dark:text-white">Browse Courses</h1>
                    <p class="text-lg text-gray-600 dark:text-gray-400 mt-2">Discover learning paths tailored for accessible development.</p>
                </div>
                
                <div class="mt-4 md:mt-0 flex gap-4 w-full md:w-auto">
                    <div class="relative w-full md:w-64">
                        <span class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i data-lucide="search" class="text-gray-400 w-5 h-5"></i>
                        </span>
                        <input type="text" placeholder="Search courses..." 
                            class="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-darkSurface text-gray-900 dark:text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary sm:text-sm transition-all" />
                    </div>
                </div>
            </div>

            <div class="flex gap-4 mb-8 overflow-x-auto no-scrollbar pb-2">
                <button class="whitespace-nowrap px-4 py-2 rounded-full bg-primary text-white font-medium text-sm">All Categories</button>
                <button class="whitespace-nowrap px-4 py-2 rounded-full bg-white dark:bg-darkSurface border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 font-medium text-sm transition-colors">Frontend</button>
                <button class="whitespace-nowrap px-4 py-2 rounded-full bg-white dark:bg-darkSurface border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 font-medium text-sm transition-colors">Design</button>
                <button class="whitespace-nowrap px-4 py-2 rounded-full bg-white dark:bg-darkSurface border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 font-medium text-sm transition-colors">Backend</button>
                <button class="whitespace-nowrap px-4 py-2 rounded-full bg-white dark:bg-darkSurface border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 font-medium text-sm transition-colors">QA</button>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="courses-grid">
                ${(window.liveCourses || mockCourses).map(course => `
                    <div class="flex flex-col bg-white dark:bg-darkSurface rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 overflow-hidden card-hover">
                        <div class="h-48 bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-900/30 dark:to-purple-900/30 w-full flex items-center justify-center p-6 relative">
                            <i data-lucide="book-open" class="w-16 h-16 text-indigo-400 opacity-50"></i>
                            <div class="absolute top-4 right-4 px-2.5 py-1 bg-white/80 dark:bg-black/50 backdrop-blur rounded-lg text-xs font-bold text-gray-800 dark:text-white shadow-sm">
                                ${course.category}
                            </div>
                        </div>
                        <div class="p-6 flex flex-col flex-grow">
                            <div class="flex items-center gap-3 text-sm text-gray-500 dark:text-gray-400 mb-3 font-medium">
                                <span class="flex items-center gap-1"><i data-lucide="bar-chart-2" class="w-4 h-4"></i> ${course.level}</span>
                                <span>•</span>
                                <span class="flex items-center gap-1"><i data-lucide="clock" class="w-4 h-4"></i> ${course.duration}</span>
                            </div>
                            <h3 class="text-xl font-bold text-gray-900 dark:text-white mb-2 leading-tight">${course.title}</h3>
                            <p class="text-gray-600 dark:text-gray-400 text-sm mb-6 flex-grow line-clamp-3">${course.description}</p>
                            
                            <div class="pt-4 border-t border-gray-100 dark:border-gray-800 flex gap-3">
                                <a href="#/course/${course.id}/video" class="flex-1 text-center py-2.5 bg-primary text-white rounded-lg font-medium hover:bg-primary/90 transition-colors shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
                                    Start Learning
                                </a>
                                <button aria-label="Save for later" class="p-2.5 border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
                                    <i data-lucide="bookmark" class="w-5 h-5"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `,
    afterRender: async () => {
        // Fetch real courses from Firestore if not already loaded
        if (!window.liveCourses) {
            try {
                let snapshot = await db.collection('courses').get();

                // --- AUTO SEED DATABASE IF EMPTY ---
                if (snapshot.empty) {
                    console.log("Collection is empty. Seeding initial data...");

                    // Add the 'video url' field to our mock courses
                    const initialData = mockCourses.map((c, index) => ({
                        ...c,
                        // Add the Generative AI video to the first course as a demo, leave others empty or add different ones
                        'video url': index === 0 ? 'https://www.youtube.com/watch?v=cZaNf2rA30k' : null
                    }));

                    // Write each course to Firestore
                    for (const course of initialData) {
                        await db.collection('courses').doc(course.id).set(course);
                    }

                    console.log("Database seeded successfully!");

                    // Refetch the newly added data
                    snapshot = await db.collection('courses').get();
                }
                // ------------------------------------

                if (!snapshot.empty) {
                    window.liveCourses = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

                    // Simple re-render for vanilla: if still on this page, refresh the root
                    if (window.appRouter.currentPath === '/courses') {
                        window.appRouter.render();
                    }
                }
            } catch (error) {
                console.error("Error fetching or seeding courses:", error);
            }
        }
    }
};
