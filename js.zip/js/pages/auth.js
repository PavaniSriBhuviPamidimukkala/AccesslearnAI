window.LoginView = {
    path: '/login',
    component: async () => `
        <div class="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
            <div class="max-w-md w-full space-y-8 bg-white dark:bg-darkSurface p-8 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-800 animate-fade-in">
                <div>
                    <div class="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-md mx-auto">
                        <i data-lucide="lock" class="text-white w-6 h-6"></i>
                    </div>
                    <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900 dark:text-white">
                        Sign in to your account
                    </h2>
                    <p class="mt-2 text-center text-sm text-gray-600 dark:text-gray-400">
                        Or
                        <a href="#/register" class="font-medium text-primary hover:text-primary/80 transition-colors">
                            create a new account
                        </a>
                    </p>
                </div>
                <form id="login-form" class="mt-8 space-y-6">
                    <div class="rounded-md shadow-sm space-y-4">
                        <div>
                            <label for="email-address" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Email address</label>
                            <input id="email-address" name="email" type="email" autocomplete="email" required 
                                class="appearance-none rounded-lg relative block w-full px-4 py-3 border border-gray-300 dark:border-gray-700 dark:bg-gray-800 placeholder-gray-500 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary focus:z-10 sm:text-sm transition-all" 
                                placeholder="Student or Admin email">
                        </div>
                        <div>
                            <label for="password" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Password</label>
                            <input id="password" name="password" type="password" autocomplete="current-password" required 
                                class="appearance-none rounded-lg relative block w-full px-4 py-3 border border-gray-300 dark:border-gray-700 dark:bg-gray-800 placeholder-gray-500 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary focus:z-10 sm:text-sm transition-all" 
                                placeholder="Password">
                        </div>
                    </div>

                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <input id="remember-me" name="remember-me" type="checkbox" 
                                class="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded">
                            <label for="remember-me" class="ml-2 block text-sm text-gray-900 dark:text-gray-300">
                                Remember me
                            </label>
                        </div>

                        <div class="text-sm">
                            <a href="#" class="font-medium text-primary hover:text-primary/80 transition-colors">
                                Forgot your password?
                            </a>
                        </div>
                    </div>

                    <div>
                        <button type="submit" 
                            class="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary shadow-lg shadow-primary/30 transition-all">
                            <span class="absolute left-0 inset-y-0 flex items-center pl-3">
                                <i data-lucide="log-in" class="h-5 w-5 text-white/70 group-hover:text-white transition-colors"></i>
                            </span>
                            Sign in
                        </button>
                    </div>
                </form>
                
                <div class="mt-6 text-center text-sm text-gray-600 dark:text-gray-400 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg border border-gray-100 dark:border-gray-700">
                    <p class="font-medium mb-1">Demo Accounts:</p>
                    <p>Student: <b>student@demo.com</b></p>
                    <p>Admin: <b>admin@demo.com</b></p>
                    <p>Password: <b>anything</b></p>
                </div>
            </div>
        </div>
    `,
    afterRender: async () => {
        const form = document.getElementById('login-form');
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email-address').value;
            const password = document.getElementById('password').value;

            try {
                const userCredential = await auth.signInWithEmailAndPassword(email, password);
                const user = userCredential.user;

                // Success toast
                if (window.accessibilityEngine) {
                    window.accessibilityEngine.showToast("Login successful! Welcome back.", "success");
                }

                // Redirect - the state listener in store.js will handle the store update
                window.appRouter.navigate('/dashboard');
            } catch (error) {
                console.error("Login Error:", error);
                if (window.accessibilityEngine) {
                    window.accessibilityEngine.showToast(error.message, "error");
                }
            }
        });
    }
};

window.RegisterView = {
    path: '/register',
    component: async () => `
        <div class="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
            <div class="max-w-md w-full space-y-8 bg-white dark:bg-darkSurface p-8 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-800 animate-fade-in">
                <div>
                    <div class="w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-md mx-auto">
                        <i data-lucide="user-plus" class="text-white w-6 h-6"></i>
                    </div>
                    <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900 dark:text-white">
                        Create an account
                    </h2>
                    <p class="mt-2 text-center text-sm text-gray-600 dark:text-gray-400">
                        Already have an account?
                        <a href="#/login" class="font-medium text-primary hover:text-primary/80 transition-colors">
                            Sign in here
                        </a>
                    </p>
                </div>
                <!-- Similar form to login for demo -->
                <form id="register-form" class="mt-8 space-y-6">
                    <div class="rounded-md shadow-sm space-y-4">
                         <div>
                            <label for="name" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Full Name</label>
                            <input id="name" name="name" type="text" required 
                                class="appearance-none rounded-lg relative block w-full px-4 py-3 border border-gray-300 dark:border-gray-700 dark:bg-gray-800 placeholder-gray-500 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary focus:z-10 sm:text-sm transition-all" 
                                placeholder="John Doe">
                        </div>
                        <div>
                            <label for="email-address" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Email address</label>
                            <input id="email-address" name="email" type="email" autocomplete="email" required 
                                class="appearance-none rounded-lg relative block w-full px-4 py-3 border border-gray-300 dark:border-gray-700 dark:bg-gray-800 placeholder-gray-500 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary focus:z-10 sm:text-sm transition-all" 
                                placeholder="Email address">
                        </div>
                        <div>
                            <label for="password" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Password</label>
                            <input id="password" name="password" type="password" required 
                                class="appearance-none rounded-lg relative block w-full px-4 py-3 border border-gray-300 dark:border-gray-700 dark:bg-gray-800 placeholder-gray-500 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary focus:z-10 sm:text-sm transition-all" 
                                placeholder="Create a password">
                        </div>
                    </div>

                    <div>
                        <button type="submit" 
                            class="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary shadow-lg shadow-primary/30 transition-all">
                            Create Account
                        </button>
                    </div>
                </form>
            </div>
        </div>
    `,
    afterRender: async () => {
        const form = document.getElementById('register-form');
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email-address').value;
            const password = document.getElementById('password').value;
            const name = document.getElementById('name').value;

            try {
                const userCredential = await auth.createUserWithEmailAndPassword(email, password);
                const user = userCredential.user;

                // Update Firestore profile for roles and extra info
                await db.collection('users').doc(user.uid).set({
                    name: name,
                    email: email,
                    role: 'student', // Default role
                    accessibilityPreference: 'normal',
                    createdAt: firebase.firestore.FieldValue.serverTimestamp()
                });

                if (window.accessibilityEngine) {
                    window.accessibilityEngine.showToast("Account created successfully!", "success");
                }

                window.appRouter.navigate('/dashboard');
            } catch (error) {
                console.error("Registration Error:", error);
                if (window.accessibilityEngine) {
                    window.accessibilityEngine.showToast(error.message, "error");
                }
            }
        });
    }
};
