window.DashboardView = {
    path: '/dashboard',
    component: async () => {
        const state = store.getState();
        const user = state.auth.user;

        if (!state.auth.isAuthenticated) {
            window.location.hash = '/login';
            return '<div class="p-8 text-center animate-pulse">Redirecting to login...</div>';
        }

        const isStudent = user.role === 'student';

        return `
            <div class="space-y-8 animate-fade-in">
                <!-- Dashboard Header -->
                <div class="flex flex-col md:flex-row justify-between items-start md:items-center p-6 bg-white dark:bg-darkSurface rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
                    <div class="flex flex-col">
                        <h1 class="text-3xl font-bold text-gray-900 dark:text-white">
                            Welcome back, ${user.name}!
                        </h1>
                        <p class="text-lg text-gray-600 dark:text-gray-400 mt-2">
                            ${isStudent ? "Here's your learning progress for today." : "Here's an overview of the platform."}
                        </p>
                    </div>
                    
                    <button id="logout-btn" class="mt-4 md:mt-0 flex items-center gap-2 px-4 py-2 border border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300 dark:border-red-900 dark:text-red-400 dark:hover:bg-red-900/30 rounded-lg transition-colors font-medium">
                        <i data-lucide="log-out" class="w-4 h-4"></i> Sign Out
                    </button>
                </div>

                <!-- Dashboard Content -->
                ${isStudent ? studentDashboardContent() : adminDashboardContent()}
            </div>
        `;
    },
    afterRender: async () => {
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                store.dispatch(logoutUser());
                window.accessibilityEngine?.showToast("Signed out successfully.", "info");
                window.appRouter.navigate('/');

                // Update Nav UI for logged out state
                updateNavAuthUI(false);
            });
        }
    }
};

function studentDashboardContent() {
    return `
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!-- Stats -->
            <div class="p-6 bg-gradient-to-br from-indigo-50 to-blue-50 dark:from-indigo-900/20 dark:to-blue-900/20 rounded-2xl border border-indigo-100 dark:border-indigo-800">
                <div class="flex items-center gap-4 text-indigo-600 dark:text-indigo-400">
                    <div class="w-12 h-12 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center">
                        <i data-lucide="book-open"></i>
                    </div>
                    <div>
                        <p class="text-sm font-medium opacity-80">Enrolled Courses</p>
                        <p class="text-2xl font-bold">4</p>
                    </div>
                </div>
            </div>
            
            <div class="p-6 bg-gradient-to-br from-emerald-50 to-green-50 dark:from-emerald-900/20 dark:to-green-900/20 rounded-2xl border border-emerald-100 dark:border-emerald-800">
                <div class="flex items-center gap-4 text-emerald-600 dark:text-emerald-400">
                    <div class="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-900/50 flex items-center justify-center">
                        <i data-lucide="award"></i>
                    </div>
                    <div>
                        <p class="text-sm font-medium opacity-80">Quizzes Passed</p>
                        <p class="text-2xl font-bold">12</p>
                    </div>
                </div>
            </div>

            <div class="p-6 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 rounded-2xl border border-amber-100 dark:border-amber-800">
                <div class="flex items-center gap-4 text-amber-600 dark:text-amber-400">
                    <div class="w-12 h-12 rounded-full bg-amber-100 dark:bg-amber-900/50 flex items-center justify-center">
                        <i data-lucide="clock"></i>
                    </div>
                    <div>
                        <p class="text-sm font-medium opacity-80">Hours Learned</p>
                        <p class="text-2xl font-bold">28h</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-8">
            <h2 class="text-2xl font-bold text-gray-900 dark:text-white mb-6">Continue Learning</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Course Card -->
                <a href="#/course/react-101/video" class="block group p-6 bg-white dark:bg-darkSurface rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 card-hover">
                    <div class="flex justify-between items-start mb-4">
                        <div class="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
                            <i data-lucide="code"></i>
                        </div>
                        <span class="px-3 py-1 bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 rounded-full text-xs font-bold">60% Complete</span>
                    </div>
                    <h3 class="text-lg font-bold text-gray-900 dark:text-white mb-2 group-hover:text-primary transition-colors">Advanced React Accessibility</h3>
                    <p class="text-sm text-gray-600 dark:text-gray-400 mb-4 line-clamp-2">Learn to build fully screen-reader compliant apps utilizing ARIA roles and keyboard management.</p>
                    
                    <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-2">
                        <div class="bg-primary h-2 rounded-full" style="width: 60%"></div>
                    </div>
                    <p class="text-xs text-gray-500 dark:text-gray-400 text-right">Resume Lesson 4</p>
                </a>
            </div>
        </div>
    `;
}

function adminDashboardContent() {
    return `
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="p-6 bg-white dark:bg-darkSurface rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
                <div class="flex items-center gap-4 text-purple-600 dark:text-purple-400">
                    <div class="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900/50 flex items-center justify-center">
                        <i data-lucide="users"></i>
                    </div>
                    <div>
                        <p class="text-sm font-medium opacity-80">Total Students</p>
                        <p class="text-2xl font-bold">1,402</p>
                    </div>
                </div>
            </div>
            <div class="p-6 bg-white dark:bg-darkSurface rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
                <div class="flex items-center gap-4 text-primary">
                    <div class="w-12 h-12 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center">
                        <i data-lucide="library"></i>
                    </div>
                    <div>
                        <p class="text-sm font-medium opacity-80">Active Courses</p>
                        <p class="text-2xl font-bold">45</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="mt-8 flex gap-4">
             <button class="px-6 py-3 bg-primary text-white rounded-lg font-medium hover:bg-primary/90 transition-colors flex items-center gap-2">
                <i data-lucide="plus"></i> Add New Course
            </button>
            <button class="px-6 py-3 bg-white dark:bg-darkSurface border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white rounded-lg font-medium hover:bg-gray-50 transition-colors flex items-center gap-2">
                <i data-lucide="settings"></i> System Settings
            </button>
        </div>
    `;
}

// Helper to update navigation links for Auth State
window.updateNavAuthUI = function updateNavAuthUI(isAuthenticated) {
    const authContainer = document.getElementById('nav-auth-container');
    if (!authContainer) return;

    if (isAuthenticated) {
        authContainer.innerHTML = `
            <a href="#/dashboard" class="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium px-3 py-2 rounded-md transition-colors">
                Dashboard
            </a>
            <a href="#/courses" class="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium px-3 py-2 rounded-md transition-colors">
                Courses
            </a>
        `;
    } else {
        authContainer.innerHTML = `
            <a href="#/login" class="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white font-medium px-3 py-2 rounded-md transition-colors">
                Log in
            </a>
            <a href="#/register" class="bg-primary text-white hover:bg-primary/90 font-medium px-4 py-2 rounded-md transition-colors">
                Sign up
            </a>
        `;
    }
}
