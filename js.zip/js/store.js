/**
 * Global State Management (Redux-lite)
 * Uses the Observer pattern to notify components of state changes.
 */

class Store {
    constructor(initialState) {
        this.state = initialState;
        this.listeners = [];
        this.initFirebaseSync();
    }

    // New: Sync with Firebase Auth
    initFirebaseSync() {
        auth.onAuthStateChanged(async (firebaseUser) => {
            if (firebaseUser) {
                try {
                    // Fetch extended profile from Firestore
                    const userDoc = await db.collection('users').doc(firebaseUser.uid).get();
                    let userData = {
                        id: firebaseUser.uid,
                        email: firebaseUser.email,
                        name: firebaseUser.displayName || firebaseUser.email.split('@')[0],
                        role: 'student' // Default
                    };

                    if (userDoc.exists) {
                        userData = { ...userData, ...userDoc.data() };
                    }

                    this.dispatch({ type: 'LOGIN_SUCCESS', payload: userData });

                    // Update accessibility mode if preference exists
                    if (userData.accessibilityPreference) {
                        this.dispatch({ type: 'SET_MODE', payload: userData.accessibilityPreference });
                    }
                } catch (error) {
                    console.error("Error fetching user profile:", error);
                }
            } else {
                this.dispatch({ type: 'LOGOUT' });
            }
        });
    }

    // Subscribe to state changes
    subscribe(listener) {
        this.listeners.push(listener);
        return () => {
            this.listeners = this.listeners.filter(l => l !== listener);
        };
    }

    // Update state and notify listeners
    dispatch(action) {
        if (typeof action === 'function') {
            action(this.dispatch.bind(this), this.getState.bind(this));
            return;
        }

        const newState = this.reducer(this.state, action);
        if (newState !== this.state) {
            this.state = newState;
            this.listeners.forEach(listener => listener(this.state));
            this.persistState(); // Optional: Save certain state to localStorage
        }
    }

    getState() {
        return this.state;
    }

    reducer(state, action) {
        switch (action.type) {
            case 'SET_MODE':
                // Side effect: Persist to Firestore if logged in
                if (state.auth.isAuthenticated && state.auth.user && state.auth.user.id) {
                    db.collection('users').doc(state.auth.user.id).update({
                        accessibilityPreference: action.payload
                    }).catch(err => console.error("Error updating preference:", err));
                }
                return {
                    ...state,
                    accessibility: {
                        ...state.accessibility,
                        mode: action.payload // 'normal', 'deaf', 'blind'
                    }
                };
            case 'LOGIN_SUCCESS':
                return {
                    ...state,
                    auth: {
                        isAuthenticated: true,
                        user: action.payload,
                    }
                };
            case 'LOGOUT':
                return {
                    ...state,
                    auth: {
                        isAuthenticated: false,
                        user: null,
                    }
                };
            default:
                return state;
        }
    }

    // Save important state to local storage
    persistState() {
        localStorage.setItem('accessLearnState', JSON.stringify({
            accessibility: this.state.accessibility,
            auth: this.state.auth
        }));
    }
}

// Load from local storage if exists
const loadState = () => {
    try {
        const serialized = localStorage.getItem('accessLearnState');
        if (serialized) {
            const parsed = JSON.parse(serialized);
            // Sanity check to clear corrupted cache from earlier bug
            if (parsed.auth?.isAuthenticated && !parsed.auth?.user?.role) {
                localStorage.removeItem('accessLearnState');
                throw new Error("Corrupted state detected, resetting.");
            }
            return {
                accessibility: parsed.accessibility || { mode: 'normal' },
                auth: parsed.auth || { isAuthenticated: false, user: null }
            };
        }
    } catch (e) {
        console.error("Could not load state", e);
    }
    return {
        accessibility: { mode: 'normal' },
        auth: { isAuthenticated: false, user: null }
    };
};

// Create the global store instance
window.store = new Store(loadState());

// Action Creators
window.setAccessibilityMode = (mode) => ({
    type: 'SET_MODE',
    payload: mode
});

window.loginUser = (user) => ({
    type: 'LOGIN_SUCCESS',
    payload: user
});

window.logoutUser = () => {
    auth.signOut().catch(err => console.error("Logout Error:", err));
    return { type: 'LOGOUT' };
};
