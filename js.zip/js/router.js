/**
 * Client-Side Router
 * Listens to hash changes and renders the corresponding view into the root element.
 */

window.Router = class Router {
    constructor(routes, rootElementId) {
        this.routes = routes;
        this.rootElement = document.getElementById(rootElementId);

        // Listen to hash changes
        window.addEventListener('hashchange', () => this.handleRouteChange());

        // Handle initial load
        window.addEventListener('load', () => this.handleRouteChange());
    }

    handleRouteChange() {
        // Get current hash, fallback to '/'
        const path = window.location.hash.slice(1) || '/';

        // Find matching route
        let route = this.routes.find(r => {
            // Basic exact match for now. In a real app we'd use regex for params (/course/:id)
            if (r.path === path) return true;

            // Check dynamic routes like /course/:id
            if (r.path.includes(':')) {
                const routeParts = r.path.split('/');
                const pathParts = path.split('/');

                if (routeParts.length === pathParts.length) {
                    const isMatch = routeParts.every((part, i) => {
                        return part.startsWith(':') || part === pathParts[i];
                    });
                    if (isMatch) {
                        // Extract params
                        this.params = {};
                        routeParts.forEach((part, i) => {
                            if (part.startsWith(':')) {
                                this.params[part.slice(1)] = pathParts[i];
                            }
                        });
                        return true;
                    }
                }
            }
            return false;
        });

        // Fallback to 404 or home
        if (!route) {
            console.warn(`Route not found for path: ${path}. Redirecting to /`);
            window.location.hash = '/';
            return;
        }

        // Execute route render function
        this.renderView(route);
    }

    async renderView(route) {
        // Clear previous content
        this.rootElement.innerHTML = '';

        try {
            // The route component should return HTML string or elements
            const content = await route.component(this.params);

            if (typeof content === 'string') {
                this.rootElement.innerHTML = content;
            } else if (content instanceof Node) {
                this.rootElement.appendChild(content);
            }

            // Execute after-render logic (for adding event listeners to new DOM)
            if (route.afterRender) {
                await route.afterRender(this.params);
            }

            // Re-initialize icons
            if (window.lucide) {
                window.lucide.createIcons();
            }

        } catch (error) {
            console.error('Error rendering route:', error);
            this.rootElement.innerHTML = `<div class="p-8 text-center text-red-600 bg-red-50 rounded-lg">
                <h2 class="text-2xl font-bold mb-2">Error Loading Page</h2>
                <p>Sorry, there was a problem loading this view.</p>
            </div>`;
        }
    }

    navigate(path) {
        window.location.hash = path;
    }
}
