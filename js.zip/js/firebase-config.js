// Firebase Configuration provided by user
const firebaseConfig = {
    apiKey: "AIzaSyCGdnBeHYVVCpQaNn44846T0q-XfVB5nvc",
    authDomain: "acceearn-aaai.firebaseapp.com",
    projectId: "acceearn-aaai",
    storageBucket: "acceearn-aaai.firebasestorage.app",
    messagingSenderId: "104222624774",
    appId: "1:104222624774:web:aec5f96bec6dc90ac18787",
    measurementId: "G-SFF3JJG7V7"
};

// Initialize Firebase
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

// Initialize Services
const auth = firebase.auth();
const db = firebase.firestore();

console.log("Firebase initialized successfully.");
